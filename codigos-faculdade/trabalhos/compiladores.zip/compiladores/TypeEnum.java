
public enum TypeEnum
{
    DOUBLE, BOOLEAN;
}
