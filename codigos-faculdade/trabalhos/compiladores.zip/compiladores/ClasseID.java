  public enum ClasseID {
    TipoBase, VarGlobal, NomeFuncao, NomeParam, VarLocal, CampoDefine; 
  }

