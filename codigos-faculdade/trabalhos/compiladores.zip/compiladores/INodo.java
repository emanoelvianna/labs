
/**
 * Write a description of interface INodo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public interface INodo
{
 
    public ResultValue avalia();
}
