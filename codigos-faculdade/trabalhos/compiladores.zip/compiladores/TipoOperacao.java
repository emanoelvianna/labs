public enum TipoOperacao
{
    ADD, 
    SUB, 
    UMINUS, 
    MULL, 
    DIV, 
    POW, 
    LESS,
    MORE,	
    ATRIB,
    IF,
    IFELSE,	
    WHILE,
    SEQ, 
    NULL
}
